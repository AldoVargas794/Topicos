import 'package:flutter/material.dart';
import 'package:flutter_application_1/views/agregarproductos.dart';
// import 'package:flutter_application_1/views/home.dart'; // Import the Home widget
import 'package:flutter_application_1/views/listaproductos.dart';
import 'package:flutter_application_1/views/producto.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final appDocumentDirectory = await getApplicationDocumentsDirectory();

  await Hive.initFlutter(appDocumentDirectory.path);
  Hive.registerAdapter(ProductoAdapter());
  await Hive.openBox<Producto>('productos');

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Inicio de Sesión',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const LoginPage(),
    );
  }
}
class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AgregarProductos(
                      onProductosUpdated: (List<Producto> updatedProductos) {
                        // Do something with updated products if needed
                      },
                    ),
                  ),
                );
              },
              child: const Text('Agregar Productos'),
            ),
            ElevatedButton(
              onPressed: () async {
                final List<Producto> updatedProductos =
                    await Hive.box<Producto>('productos').values.toList();
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ListaProductos(
                      listaProductos: updatedProductos,
                    ),
                  ),
                );
              },
              child: const Text('Ver Lista'),
            ),
            const SizedBox(height: 20), // Espacio entre los botones existentes y los nuevos
            ElevatedButton(
              onPressed: () {
                // Lógica para navegar a la pantalla de categorías
              },
              child: const Text('Categorías'),
            ),
            ElevatedButton(
              onPressed: () {
                // Lógica para navegar a la pantalla de tickets
              },
              child: const Text('Ticket'),
            ),
          ],
        ),
      ),
    );
  }
}



class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  String _email = '';
  String _password = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Iniciar Sesión'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Email',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  hintText: 'Correo Electronico',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Introduce aquí tu correo';
                  }
                  return null;
                },
                onChanged: (value) {
                  setState(() {
                    _email = value;
                  });
                },
              ),
              const SizedBox(height: 16.0),
              const Text(
                'Contraseña',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              TextFormField(
                obscureText: true,
                decoration: const InputDecoration(
                  hintText: 'Contraseña',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese su contraseña';
                  }
                  return null;
                },
                onChanged: (value) {
                  setState(() {
                    _password = value;
                  });
                },
              ),
              const SizedBox(height: 16.0),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    _login();
                  },
                  child: const Text('Iniciar Sesión'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _login() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Iniciando Sesión...')),
      );
      _formKey.currentState!.reset();

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => Home(),
        ),
      );
    }
  }
}


