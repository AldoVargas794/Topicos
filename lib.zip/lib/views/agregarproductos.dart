import 'package:flutter/material.dart';
import 'package:flutter_application_1/views/producto.dart';
import 'package:hive/hive.dart';

class AgregarProductos extends StatefulWidget {
  final Function(List<Producto>) onProductosUpdated;

  AgregarProductos({required this.onProductosUpdated});

  @override
  _AgregarProductosState createState() => _AgregarProductosState();
}

class _AgregarProductosState extends State<AgregarProductos> {
  String nombre = '';
  String cantidad = '';
  String precio = '';

  // Abre la caja de Hive para guardar los productos
  late Box<Producto> productosBox;

  @override
  void initState() {
    super.initState();
    _openBox();
  }

  Future<void> _openBox() async {
    productosBox = await Hive.openBox<Producto>('productos');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agregar Productos'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Nombre',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            TextFormField(
              onChanged: (value) {
                setState(() {
                  nombre = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Nombre del Producto',
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              'Cantidad',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            TextFormField(
              onChanged: (value) {
                setState(() {
                  cantidad = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Cantidad del Producto',
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              'Precio',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            TextFormField(
              onChanged: (value) {
                setState(() {
                  precio = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Precio del Producto',
              ),
            ),
            SizedBox(height: 16.0),
            Center(
              child: ElevatedButton(
                onPressed: () async {
                  // Guarda el producto en Hive
                  await productosBox.add(
                    Producto(
                      nombre: nombre,
                      cantidad: cantidad,
                      precio: precio,
                    ),
                  );

                  // Obtén la lista actualizada de productos
                  final List<Producto> updatedProductos = productosBox.values.toList();

                  // Llama a la función de devolución de llamada para pasar la lista actualizada
                  widget.onProductosUpdated(updatedProductos);

                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: Text('Producto Guardado'),
                      content: Text('El producto $nombre ha sido guardado.'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('Cerrar'),
                        ),
                      ],
                    ),
                  );

                  // Limpia los campos después de guardar
                  setState(() {
                    nombre = '';
                    cantidad = '';
                    precio = '';
                  });
                },
                child: Text('Guardar Producto'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
