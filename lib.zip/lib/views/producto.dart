import 'package:hive/hive.dart';

part 'producto.g.dart';

@HiveType(typeId: 0)
class Producto extends HiveObject {
  @HiveField(0)
  final String nombre;
  
  @HiveField(1)
  final String cantidad;
  
  @HiveField(2)
  final String precio;

  Producto({
    required this.nombre,
    required this.cantidad,
    required this.precio,
  });
}
