import 'package:flutter/material.dart';
import 'producto.dart';

class EliminarProductos extends StatefulWidget {
  final List<Producto> listaProductos;

  EliminarProductos({required this.listaProductos});

  @override
  _EliminarProductosState createState() => _EliminarProductosState();
}

class _EliminarProductosState extends State<EliminarProductos> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Eliminar Productos'),
      ),
      body: ListView.builder(
        itemCount: widget.listaProductos.length,
        itemBuilder: (context, index) {
          final producto = widget.listaProductos[index];
          return ListTile(
            title: Text(producto.nombre),
            subtitle: Text('Cantidad: ${producto.cantidad}, Precio: ${producto.precio}'),
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: Text('Eliminar Producto'),
                    content: Text('¿Estás seguro de que deseas eliminar el producto ${producto.nombre}?'),
                    actions: [
                      TextButton(
                        onPressed: () {
                          setState(() {
                            widget.listaProductos.removeAt(index);
                          });
                          Navigator.pop(context);
                        },
                        child: Text('Sí'),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('Cancelar'),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
