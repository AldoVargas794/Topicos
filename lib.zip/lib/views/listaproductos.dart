import 'package:flutter/material.dart';
import 'package:flutter_application_1/views/producto.dart';
import 'package:hive/hive.dart';

class ListaProductos extends StatelessWidget {
  final List<Producto> listaProductos;

  const ListaProductos({Key? key, required this.listaProductos}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Productos'),
      ),
      body: listaProductos.isEmpty
          ? Center(child: Text('No hay productos'))
          : ListView.builder(
              itemCount: listaProductos.length,
              itemBuilder: (context, index) {
                final producto = listaProductos[index];

                return ListTile(
                  title: Text('Nombre: ${producto.nombre}'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Cantidad: ${producto.cantidad}'),
                      Text('Precio: ${producto.precio}'),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () {
                          // Lógica para editar el producto
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          // Eliminar el producto de la lista y de Hive
                          final box = Hive.box<Producto>('productos');
                          box.deleteAt(index); // Elimina el producto de Hive
                          listaProductos.removeAt(index); // Elimina el producto de la lista
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
